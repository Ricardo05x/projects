package com.example.quotes.data.model

data class Quote(
    val id: String = "",
    val text: String = "",
    val author: String = "",
    val timestamp: Long = System.currentTimeMillis()
) 
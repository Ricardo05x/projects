package com.example.quotes.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quotes.data.model.Quote
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class UserViewModel : ViewModel() {
    private val firestore = FirebaseFirestore.getInstance()
    private val quotesCollection = firestore.collection("quotes")

    private val _quotes = MutableStateFlow<List<Quote>>(emptyList())
    val quotes: StateFlow<List<Quote>> = _quotes

    init {
        loadQuotes()
    }

    private fun loadQuotes() {
        viewModelScope.launch {
            try {
                val snapshot = quotesCollection.get().await()
                val quotesList = snapshot.documents.mapNotNull { doc ->
                    doc.toObject(Quote::class.java)?.copy(id = doc.id)
                }
                _quotes.value = quotesList
            } catch (_: Exception) {
                // Handle error
            }
        }
    }
} 
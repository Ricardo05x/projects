package com.example.quotes.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quotes.R

@Composable
fun Image10Screen(onBackClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // Background image (logo Flutter neon)
        Image(
            painter = painterResource(id = R.drawable.image10), // ganti dengan nama file gambar Anda
            contentDescription = "Background Flutter Neon",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Konten quote di tengah layar
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = """
                    If you're not a good shot today, don't worry. There are other ways to be useful.
                    
                    I always bring my best. That's why I always win.
                    
                    If you fall here, stand up. Stronger.
                """.trimIndent(),
                color = Color.White,
                fontSize = 22.sp,
                textAlign = TextAlign.Center,
                lineHeight = 30.sp
            )
        }

        // Tombol kembali (opsional, di bawah)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Button(
                onClick = onBackClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                )
            ) {
                Text("Kembali Ke Kumpulan Quotes", fontWeight = FontWeight.Bold)
            }
        }
    }
}
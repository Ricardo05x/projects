package com.example.quotes.data.model

data class User(
    val id: String = "",
    val username: String = "",
    val isAdmin: Boolean = false
) 
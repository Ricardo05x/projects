package com.example.quotes.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quotes.R

@Composable
fun Image4Screen(onBackClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // Background image (senja blur)
        Image(
            painter = painterResource(id = R.drawable.image4),
            contentDescription = "Background Senja",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Konten puisi di tengah layar
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center // <-- ini yang membuat konten di tengah
        ) {
            // Judul puisi
            Text(
                text = "Senja yang Hilang",
                fontWeight = FontWeight.Bold,
                fontSize = 32.sp,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 20.dp)
            )

            // Isi puisi
            Text(
                text = """
                    Di batas langit yang merona, angin senja menyebut namamu. Bersama mentari yang perlahan tenggelam, kutitipkan rindu yang tak kunjung padam. Langkahmu telah pergi, namun jejakmu tetap abadi.

                    Di batas cakrawala, kusaksikan kenangan terbakar jingga. Malam segera merayap, membawa dingin yang memeluk sepi. Aku bertanya pada bayang-bayang, adakah engkau masih mengingatku?

                    Tapi senja tak pernah menjawab, hanya meninggalkan semburat duka. Seperti hatiku, yang perlahan meredup dalam ingatan. Malam datang, membawaku ke dalam kesunyian tanpa akhir.
                """.trimIndent(),
                color = Color.White,
                fontSize = 20.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // Penulis
            Text(
                text = "- Levi",
                color = Color.White,
                fontStyle = FontStyle.Italic,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Tombol kembali (opsional)
            Button(
                onClick = onBackClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                )
            ) {
                Text("Kembali Ke Kumpulan Quotes", fontWeight = FontWeight.Bold)
            }
        }
    }
}
@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.quotes.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.quotes.data.model.Quote
import com.example.quotes.ui.viewmodel.UserViewModel

@Composable
fun UserScreen(
    onLogout: () -> Unit,
    viewModel: UserViewModel
) {
    val quotes by viewModel.quotes.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Quotes") },
                actions = {
                    TextButton(onClick = onLogout) {
                        Text("Logout")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(quotes) { quote ->
                QuoteCard(quote = quote)
            }
        }
    }
}

@Composable
fun QuoteCard(quote: Quote) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = quote.text,
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                text = "- ${quote.author}",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
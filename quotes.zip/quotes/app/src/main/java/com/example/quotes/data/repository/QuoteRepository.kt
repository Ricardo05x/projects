package com.example.quotes.data.repository

import android.util.Log
import com.example.quotes.data.model.Quote
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await

class QuoteRepository {
    private val TAG = "QuoteRepository"
    private val firestore = FirebaseFirestore.getInstance()
    private val quotesCollection = firestore.collection("quotes")

    init {
        // Initialize quotes collection with default data
        initializeQuotesCollection()
    }

    private fun initializeQuotesCollection() {
        quotesCollection.get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    Log.d(TAG, "Initializing quotes collection with default data")
                    val defaultQuotes = listOf(
                        Quote(
                            text = "The only way to do great work is to love what you do.",
                            author = "Steve Jobs",
                            timestamp = System.currentTimeMillis()
                        ),
                        Quote(
                            text = "Innovation distinguishes between a leader and a follower.",
                            author = "Steve Jobs",
                            timestamp = System.currentTimeMillis() + 1000
                        ),
                        Quote(
                            text = "Stay hungry, stay foolish.",
                            author = "Steve Jobs",
                            timestamp = System.currentTimeMillis() + 2000
                        )
                    )

                    defaultQuotes.forEach { quote ->
                        quotesCollection.add(quote)
                            .addOnSuccessListener { documentReference ->
                                Log.d(TAG, "Added default quote with ID: ${documentReference.id}")
                            }
                            .addOnFailureListener { e ->
                                Log.e(TAG, "Error adding default quote", e)
                            }
                    }
                } else {
                    Log.d(TAG, "Quotes collection already has ${documents.size()} documents")
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error checking quotes collection", e)
            }
    }

    suspend fun addQuote(quote: Quote): Result<Quote> {
        return try {
            val documentRef = quotesCollection.add(quote).await()
            val newQuote = quote.copy(id = documentRef.id)
            Result.success(newQuote)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding quote: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun updateQuote(quote: Quote): Result<Quote> {
        return try {
            quotesCollection.document(quote.id).set(quote).await()
            Result.success(quote)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating quote: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun deleteQuote(quoteId: String): Result<Unit> {
        return try {
            quotesCollection.document(quoteId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting quote: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun getQuotes(): Flow<List<Quote>> = flow {
        try {
            Log.d(TAG, "Starting to fetch quotes from Firestore")
            val snapshot = quotesCollection
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get()
                .await()
            
            Log.d(TAG, "Fetched ${snapshot.documents.size} quotes from Firestore")
            
            val quotes = snapshot.documents.mapNotNull { doc ->
                try {
                    doc.toObject(Quote::class.java)?.copy(id = doc.id)
                } catch (e: Exception) {
                    Log.e(TAG, "Error converting document to Quote: ${e.message}", e)
                    null
                }
            }
            
            Log.d(TAG, "Successfully converted ${quotes.size} quotes")
            emit(quotes)
        } catch (e: Exception) {
            Log.e(TAG, "Error getting quotes: ${e.message}", e)
            emit(emptyList())
        }
    }
} 
package com.example.quotes.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quotes.R

@Composable
fun Image7Screen(onBackClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // Background image
        Image(
            painter = painterResource(id = R.drawable.image7), // ganti dengan nama file gambar Anda
            contentDescription = "Background Pada Suatu Hari Nanti",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Overlay gelap transparan
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.4f))
        )

        // Konten puisi
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Judul puisi
            Text(
                text = "PADA SUATU HARI NANTI",
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 20.dp)
            )

            // Isi puisi
            Text(
                text = """
                    Pada suatu hari nanti
                    jasadku tak akan ada lagi
                    tapi dalam bait-bait sajak ini
                    kau tak akan kurelakan sendiri

                    Pada suatu hari nanti
                    suaraku tak terdengar lagi
                    tapi di antara larik-larik sajak ini
                    kau akan tetap kusiasati

                    Pada suatu hari nanti
                    impianku pun tak dikenal lagi
                    namun di sela-sela huruf sajak ini
                    kau tak akan letih-letihnya kucari
                """.trimIndent(),
                color = Color.White,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Penulis
            Text(
                text = "- Sapardi Djoko Damono | 1991.",
                color = Color.White,
                fontStyle = FontStyle.Italic,
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            Spacer(modifier = Modifier.weight(1f))

            // Tombol kembali (opsional)
            Button(
                onClick = onBackClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                )
            ) {
                Text("Kembali Ke Kumpulan Quotes", fontWeight = FontWeight.Bold)
            }
        }
    }
}
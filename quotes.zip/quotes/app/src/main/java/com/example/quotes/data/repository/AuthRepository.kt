package com.example.quotes.data.repository

import android.util.Log
import com.example.quotes.data.model.User
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class AuthRepository {
    private val TAG = "AuthRepository"
    private val firestore = FirebaseFirestore.getInstance()
    private val usersCollection = firestore.collection("users")
    private var currentUser: User? = null

    init {
        // Create default users if not exists
        createDefaultUsersIfNotExists()
    }

    private fun createDefaultUsersIfNotExists() {
        // Create admin user
        createUserIfNotExists(
            username = "admin",
            password = "admin123",
            isAdmin = true
        )

        // Create regular user
        createUserIfNotExists(
            username = "user",
            password = "user123",
            isAdmin = false
        )
    }

    private fun createUserIfNotExists(username: String, password: String, isAdmin: Boolean) {
        usersCollection
            .whereEqualTo("username", username)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    Log.d(TAG, "Creating $username user...")
                    val userData = hashMapOf(
                        "username" to username,
                        "password" to password,
                        "isAdmin" to isAdmin
                    )
                    usersCollection.add(userData)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "$username user created with ID: ${documentReference.id}")
                        }
                        .addOnFailureListener { e ->
                            Log.e(TAG, "Error creating $username user", e)
                        }
                } else {
                    Log.d(TAG, "$username user already exists")
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error checking $username user", e)
            }
    }

    suspend fun login(username: String, password: String): Result<User> {
        return try {
            if (!checkConnection()) {
                Log.e(TAG, "No internet connection")
                return Result.failure(Exception("No internet connection"))
            }

            Log.d(TAG, "Starting login process for username: $username")
            
            // First, get all users to debug
            val allUsers = usersCollection.get().await()
            Log.d(TAG, "Total users in collection: ${allUsers.size()}")
            
            // Log all users for debugging
            allUsers.documents.forEach { doc ->
                Log.d(TAG, """
                    User in DB:
                    - ID: ${doc.id}
                    - Username: ${doc.getString("username")}
                    - Password: ${doc.getString("password")}
                    - isAdmin: ${doc.getBoolean("isAdmin")}
                """.trimIndent())
            }

            // Try to find user by username
            val querySnapshot = usersCollection
                .whereEqualTo("username", username.trim())
                .get()
                .await()

            Log.d(TAG, "Query completed, documents found: ${querySnapshot.documents.size}")

            if (querySnapshot.isEmpty) {
                Log.e(TAG, "No user found with username: $username")
                return Result.failure(Exception("Invalid username or password"))
            }

            val document = querySnapshot.documents[0]
            val storedUsername = document.getString("username")?.trim()
            val storedPassword = document.getString("password")?.trim()
            
            Log.d(TAG, """
                Found user:
                - Stored username: $storedUsername
                - Input username: ${username.trim()}
                - Stored password: $storedPassword
                - Input password: ${password.trim()}
            """.trimIndent())
            
            // Check username and password
            if (storedUsername != username.trim() || storedPassword != password.trim()) {
                Log.e(TAG, "Username or password mismatch")
                return Result.failure(Exception("Invalid username or password"))
            }

            val user = User(
                id = document.id,
                username = storedUsername ?: "",
                isAdmin = document.getBoolean("isAdmin") == true
            )

            Log.d(TAG, "Login successful for user: ${user.username}, isAdmin: ${user.isAdmin}")
            currentUser = user
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "Login error: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun getCurrentUser(): User? = currentUser

    fun logout() {
        currentUser = null
    }

    private suspend fun checkConnection(): Boolean {
        return try {
            firestore.collection("users").limit(1).get().await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Connection check failed: ${e.message}", e)
            false
        }
    }
} 
package com.example.quotes.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.quotes.ui.screens.*
import com.example.quotes.ui.viewmodel.AuthViewModel
import com.example.quotes.ui.viewmodel.QuoteViewModel
import com.example.quotes.ui.viewmodel.UserViewModel

@Composable
fun AppNavigation(
    navController: NavHostController,
    authViewModel: AuthViewModel,
    userViewModel: UserViewModel,
    quoteViewModel: QuoteViewModel
) {
    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginScreen(
                viewModel = authViewModel,
                onNavigateToAdmin = { navController.navigate("admin") },
                onNavigateToUser = { navController.navigate("home") }
            )
        }
        composable("admin") {
            AdminScreen(
                viewModel = quoteViewModel,
                onLogout = {
                    authViewModel.logout()
                    navController.navigate("login") {
                        popUpTo("admin") { inclusive = true }
                    }
                },
                onNavigateToImage = { navController.navigate("image") }
            )
        }
        composable("home") {
            HomeScreen(
                viewModel = userViewModel,
                onLogout = {
                    authViewModel.logout()
                    navController.navigate("login") {
                        popUpTo("home") { inclusive = true }
                    }
                },
                onNavigateToImage = { index -> navController.navigate("image$index") }
            )
        }
        composable("image1") {
            Image1Screen(onBackClick = { navController.popBackStack() })
        }
        composable("image2") {
            Image2Screen(onBackClick = { navController.popBackStack() })
        }
        composable("image3") {
            Image3Screen(onBackClick = { navController.popBackStack() })
        }
        composable("image4") {
            Image4Screen(onBackClick = { navController.popBackStack() })
        }
        composable("image5") {
            Image5Screen(onBackClick = { navController.popBackStack() })
        }
        composable("image6") {
            Image6Screen(onBackClick = { navController.popBackStack() })
        }
        composable("image7") {
            Image7Screen(onBackClick = { navController.popBackStack() })
        }
        composable("image8") {
            Image8Screen(onBackClick = { navController.popBackStack() })
        }
        composable("image9") {
            Image9Screen(onBackClick = { navController.popBackStack() })
        }
        composable("image10") {
            Image10Screen(onBackClick = { navController.popBackStack() })
        }
    }
} 
package com.example.quotes.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val DeepBlue = Color(0xFF1A237E)      // Primary deep blue
val RoyalBlue = Color(0xFF0D47A1)     // Secondary blue
val GoldAccent = Color(0xFFD4AF37)    // Elegant gold accent
val CreamWhite = Color(0xFFF5F5F5)    // Soft cream white
val LightGray = Color(0xFFE0E0E0)     // Light gray for subtle elements

// Dark Theme Colors
val NavyBlue = Color(0xFF0A1929)      // Deep navy for dark theme
val MidnightBlue = Color(0xFF1B3B5A)  // Rich midnight blue
val AntiqueGold = Color(0xFFB8860B)   // Antique gold for dark theme
val DarkGray = Color(0xFF424242)      // Dark gray for subtle elements
val OffWhite = Color(0xFFF0F0F0)      // Off-white for text

// Common Colors
val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)
val ErrorRed = Color(0xFFB00020)      // Classic error red
val SuccessGreen = Color(0xFF2E7D32)  // Deep success green
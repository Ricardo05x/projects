package com.example.quotes.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quotes.R

@Composable
fun Image3Screen(onBackClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // Background image (laut)
        Image(
            painter = painterResource(id = R.drawable.image3), // ganti dengan nama file gambar laut Anda
            contentDescription = "Background Sea",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Overlay gelap agar teks mudah dibaca
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.3f))
        )

        // Konten puisi
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.Start
        ) {
            // Judul puisi
            Text(
                text = "Senja di Pelabuhan Kecil",
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                color = Color.White,
                textAlign = TextAlign.Start,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Isi puisi
            Text(
                text = """
                    Ini kali tidak ada yang mencari cinta,
                    Di antara gudang, rumah tua, pada cerita,
                    Tiang serta temali. Kapal, perahu tiada berlaut,
                    Menghembus diri dalam mempercaya mau berpuat,

                    Gerimis mempercepat kelam. Ada juga kelepak elang,
                    Menyinggung muram, desir hari lari berenang,
                    Menemu bujuk pangkal akanan. Tidak bergerak,
                    Dan kini tanah dan air tidur hilang ombak,

                    Tiada lagi. Aku sendiri. Berjalan,
                    Menyisir semenanjung, masih pengap harap,
                    Sekali tiba di ujung dan sekalian selamat jalan,
                    Dari pantai keempat, sedu penghabisan bisa terdekap,
                """.trimIndent(),
                color = Color.White,
                fontSize = 17.sp,
                textAlign = TextAlign.Start,
                modifier = Modifier.padding(bottom = 18.dp)
            )

            // Penulis
            Text(
                text = "Chairil Anwar, 1946",
                color = Color.White,
                fontStyle = FontStyle.Italic,
                fontSize = 15.sp,
                textAlign = TextAlign.Start,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            Spacer(modifier = Modifier.weight(1f))

            // Tombol kembali
            Button(
                onClick = onBackClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                )
            ) {
                Text("Kembali Ke Kumpulan Quotes", fontWeight = FontWeight.Bold)
            }
        }
    }
}
package com.example.quotes.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quotes.data.model.Quote
import com.example.quotes.data.repository.QuoteRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class QuoteViewModel(
    private val repository: QuoteRepository = QuoteRepository()
) : ViewModel() {
    private val tag = "QuoteViewModel"

    private val _quotes = MutableStateFlow<List<Quote>>(emptyList())
    val quotes: StateFlow<List<Quote>> = _quotes

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        Log.d(tag, "Initializing QuoteViewModel")
        loadQuotes()
    }

    private fun loadQuotes() {
        Log.d(tag, "Loading quotes")
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                
                repository.getQuotes()
                    .catch { e ->
                        Log.e(tag, "Error in quotes flow: ${e.message}", e)
                        _error.value = e.message
                        _isLoading.value = false
                    }
                    .collect { quotes ->
                        Log.d(tag, "Received ${quotes.size} quotes")
                        _quotes.value = quotes
                        _isLoading.value = false
                    }
            } catch (e: Exception) {
                Log.e(tag, "Error loading quotes: ${e.message}", e)
                _error.value = e.message
                _isLoading.value = false
            }
        }
    }

    fun addQuote(text: String, author: String) {
        Log.d(tag, "Adding new quote: $text by $author")
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                
                val quote = Quote(text = text, author = author)
                repository.addQuote(quote)
                    .onSuccess {
                        Log.d(tag, "Successfully added quote")
                        loadQuotes()
                    }
                    .onFailure { e ->
                        Log.e(tag, "Error adding quote: ${e.message}", e)
                        _error.value = e.message
                    }
            } catch (e: Exception) {
                Log.e(tag, "Error in addQuote: ${e.message}", e)
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun updateQuote(quote: Quote) {
        Log.d(tag, "Updating quote: ${quote.id}")
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                
                repository.updateQuote(quote)
                    .onSuccess {
                        Log.d(tag, "Successfully updated quote")
                        loadQuotes()
                    }
                    .onFailure { e ->
                        Log.e(tag, "Error updating quote: ${e.message}", e)
                        _error.value = e.message
                    }
            } catch (e: Exception) {
                Log.e(tag, "Error in updateQuote: ${e.message}", e)
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteQuote(quoteId: String) {
        Log.d(tag, "Deleting quote: $quoteId")
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                
                repository.deleteQuote(quoteId)
                    .onSuccess {
                        Log.d(tag, "Successfully deleted quote")
                        loadQuotes()
                    }
                    .onFailure { e ->
                        Log.e(tag, "Error deleting quote: ${e.message}", e)
                        _error.value = e.message
                    }
            } catch (e: Exception) {
                Log.e(tag, "Error in deleteQuote: ${e.message}", e)
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun clearError() {
        _error.value = null
    }
} 
package com.example.quotes.ui.viewmodel

import com.example.quotes.data.model.User

sealed class AuthState {
    object Initial : AuthState()
    object Loading : AuthState()
    data class Success(val user: User, val isAdmin: Boolean) : AuthState()
    data class Error(val message: String) : AuthState()
} 